package seleniumsessions;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Locators {

	public static void main(String[] args) {
		
		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();
		driver.get("https://classic.crmpro.com/index.html");
		
		By username = By.name("testing");
		By Password = By.name("Password");
		
		//name: can be duplicated
		/*driver.findElement(By.name("username")).sendKeys("testing");
		driver.findElement(By.name("password")).sendKeys("password");*/
		
          //class name:Can be duplicate
		//driver.findElement(By.className("abc")).sendKeys("123");
		
		//xpath:is not an attribute,its a locator
		//address of the element in HTML DOM
		//driver.findElement(By.xpath("//*[@id=\"loginForm\"]/div/input[1]")).sendKeys("testing");
		
		//cssselector: is not an attribute
		//CSS: cascaded style sheet
		driver.findElement(By.cssSelector("#loginForm > div > input:nth-child(1)")).sendKeys("testing");
	    
		//partialLinkText:Only for links:Links are always represented by tags:/a
		driver.findElement(By.partialLinkText("Forgotten")).click();
	
	}

}
