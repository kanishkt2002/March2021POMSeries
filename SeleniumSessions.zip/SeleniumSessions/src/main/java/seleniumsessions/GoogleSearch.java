package seleniumsessions;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class GoogleSearch {
	static WebDriver driver;
	public static void main(String[] args) throws InterruptedException {
		
			
			WebDriverManager.chromedriver().setup();
			driver = new ChromeDriver();
			
			driver.get("https://www.google.com/");
			driver.findElement(By.name("q")).sendKeys("Naveen AutomationLabs");
			Thread.sleep(2000);
			By suggList= By.xpath("//ul[@role='listbox']//div[@class='wM6W7d']//span");
			suggList(suggList,"naveen automationlabs youtube");
			
			
				}
	      public static void suggList(By Locator, String Value) {
	    	  List<WebElement> suggList = 
						driver.findElements(Locator);
				
				System.out.println(suggList);
				for(WebElement e: suggList) {
					System.out.println(e.getText());
					if(e.getText().equals(Value)) {
						e.click();
						break;
					}
					
				}
		
	      }

}
