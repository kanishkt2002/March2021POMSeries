package seleniumsessions;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

import io.github.bonigarcia.wdm.WebDriverManager;

public class RightClickConcept {

	    static WebDriver driver;
		public static void main(String[] args) throws InterruptedException {
			
				
				WebDriverManager.chromedriver().setup();
				driver = new ChromeDriver();
				driver.manage().window().maximize();
				
				driver.get("https://swisnl.github.io/jQuery-contextMenu/demo.html");
				
				WebElement rightClick = driver.findElement(By.xpath("//span[text()='right click me']"));
				
				Actions act = new Actions(driver);
				
				act.contextClick(rightClick).perform();
				By rightList = By.xpath("//ul[@class='context-menu-list context-menu-root']//span");
				rightClickConcept(rightList, "Copy");
				
				/*List<WebElement> rightList = driver.findElements(By.xpath("//ul[@class='context-menu-list context-menu-root']//span"));
                
				for(WebElement e: rightList) {
					System.out.println(e.getText());
					if(e.getText().equals("Copy")) {
						e.click();
						break;
					}
				}*/
	}
		public static void rightClickConcept(By locator,String Value) {
			List<WebElement> rightList = driver.findElements(locator);
            
			for(WebElement e: rightList) {
				System.out.println(e.getText());
				if(e.getText().equals(Value)) {
					e.click();
					break;
				}
			}
			
		}
		   

}
