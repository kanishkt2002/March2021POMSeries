package seleniumsessions;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import io.github.bonigarcia.wdm.WebDriverManager;

public class HeadlessMode {

	public static void main(String[] args) {
		
		WebDriverManager.chromedriver().setup();
		ChromeOptions co = new ChromeOptions();
		//co.addArguments("--headless");
		co.addArguments("--incognito");
		
		WebDriver driver = new ChromeDriver(co);
		
		/*WebDriverManager.firefoxdriver().setup();
		FirefoxOptions fo = new FirefoxOptions();
		fo.addArguments("--headless");
		
		WebDriver driver = new FirefoxDriver(fo);*/
		
		driver.get("https://www.google.com"); //launch url
        String s = driver.getTitle(); //get title
        System.out.println(s);
        
        //Verification point/Checkpoint/act vs exp result:
        if(s.equals("Google")) {
        	System.out.println("Title is correct");
        }else {
        	System.out.println("Wrong title");
        }
        System.out.println(driver.getCurrentUrl());
        
       // System.out.println(driver.getPageSource());
        
        //close the browser:
        driver.quit();
       // driver.close();

	}

}
