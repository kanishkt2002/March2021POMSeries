package seleniumsessions;

public class CSSSelector {

	public static void main(String[] args) {
		
		//CSSSelector: is a locator,not an attribute
		
		//By.cssSelector("")
		//id --> #id
		//#username
		//input#username
		//class --> .class
		//.login-email
		
		//class c1 c2 c3
		//.c1.c2.c3....cn
		//input.form-control.private-form_control.login-email
		
         //htmltag[attr = 'value']
		//input[id='username']--css
		//input[@id='username']-- xpath
		//input[type='email']
		
		//htmltag[attr1='value'][attr2='value']
		//input[type='email'][id='username']
		
		// input[id*='user] --contains
		//input[name* = 'name'][type='text']
		//input[id^='value'] -- starts with
		//input[id$='value']--ends with
		
		//parent to child:
		//div.parent child
		//div.private-form_input-wrapper input
		//div.private-form_input-wrapper > input
	}

}
