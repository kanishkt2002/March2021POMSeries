package seleniumsessions;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class WebdriverBasics {

	public static void main(String[] args) {
		
		//IllegalStateException-if server is not started then browser will not launch,Setproperty by giving the chromedriver path
		
		/*System.setProperty("webdriver.chrome.driver","C:\\Users\\ktiwari\\Downloads\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();*/ //Top Casting
		
		System.setProperty("webdriver.gecko.driver","C:\\Users\\ktiwari\\Downloads\\geckodriver-v0.29.1-win64\\geckodriver.exe");
		WebDriver driver = new FirefoxDriver();
        driver.get("https://www.google.com"); //launch url
        String s = driver.getTitle(); //get title
        System.out.println(s);
        
        //Verification point/Checkpoint/act vs exp result:
        if(s.equals("Google")) {
        	System.out.println("Title is correct");
        }else {
        	System.out.println("Wrong title");
        }
        System.out.println(driver.getCurrentUrl());
        
       // System.out.println(driver.getPageSource());
        
        //close the browser:
        driver.quit();
       // driver.close();
		
	}

}
