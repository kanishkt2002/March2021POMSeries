package seleniumsessions;

import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class BrowserWindowPopUpHandle {
	static WebDriver driver;

	public static void main(String[] args) {
		
		//new browser tab/new browser window pop up
		//its having its own title,url,html,dom
		//Advertisement pop ups--nakri.com
		
		//Limitation: random pop ups ---cant be handle
		
		
		
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		driver.get("https://opensource-demo.orangehrmlive.com/");
	    
        driver.findElement(By.xpath("//img[@alt='OrangeHRM on youtube']")).click();
        driver.findElement(By.xpath("//img[@alt='LinkedIn OrangeHRM group']")).click();
        driver.findElement(By.xpath("//img[@alt='OrangeHRM on Facebook']")).click();
        driver.findElement(By.xpath("//img[@alt='OrangeHRM on twitter']")).click();
        
        
        //collect the window IDs:
        //driver.getWindowHandles()  --for the current window,get the window id
        Set<String> handles = driver.getWindowHandles();
        
        Iterator<String> it =handles.iterator(); //iterator are used to store collections which o not have any order
        String parentWindowId = it.next();  //to move to next element in iteration
        System.out.println("parent window id is:" + parentWindowId);
        
        String childWindowId1 = it.next();
        System.out.println("Child Window id is: " +childWindowId1);
        
        String childWindowId2 = it.next();
        System.out.println("Child Window id is: " +childWindowId2);
        
        String childWindowId3 = it.next();
        System.out.println("Child Window id is: " +childWindowId3);
        
        String childWindowId4 = it.next();
        System.out.println("Child Window id is: " +childWindowId4);
        
        //Switching to child Window:
        
        driver.switchTo().window(childWindowId1);
        System.out.println("child window title is: " + driver.getTitle());
        System.out.println("child window url is: " + driver.getCurrentUrl());
        
        //close the child window:
        driver.close();
        
        driver.switchTo().window(childWindowId2);
        System.out.println("child window title is: " + driver.getTitle());
        System.out.println("child window url is: " + driver.getCurrentUrl());
        
        //close the child window:
        driver.close();
        
        driver.switchTo().window(childWindowId3);
        System.out.println("child window title is: " + driver.getTitle());
        System.out.println("child window url is: " + driver.getCurrentUrl());
        
        //close the child window:
        driver.close();
        
        driver.switchTo().window(childWindowId4);
        System.out.println("child window title is: " + driver.getTitle());
        System.out.println("child window url is: " + driver.getCurrentUrl());
        
        //close the child window:
        driver.close();
        
        //Switching back to the parent window:
        driver.switchTo().window(parentWindowId);
        System.out.println("parent window title is: " + driver.getTitle());
        System.out.println("parent window url is: " + driver.getCurrentUrl());
        
        //close the parent window:
        driver.quit();
	}

}
