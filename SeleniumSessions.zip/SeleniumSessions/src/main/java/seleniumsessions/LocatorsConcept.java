package seleniumsessions;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class LocatorsConcept {
	static WebDriver driver;

	public static void main(String[] args) {
		
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		driver.get("https://www.orangehrm.com/orangehrm-30-day-trial/");
		
		//create webelement --> (By id,name,xpath,css etc -->perform actions(click,sendkeys,gettext..))
		//HTML DOM: Document Object Model
		//1.id
		//1st Approach to identify elements and enter input
//		driver.findElement(By.id("Form_submitForm_FirstName")).sendKeys("Testing");
	//	driver.findElement(By.id("Form_submitForm_LastName")).sendKeys("Test");
		
		//2nd approach to identify elements and enter input
		/*WebElement fname = driver.findElement(By.id("Form_submitForm_FirstName"));
		WebElement lname = driver.findElement(By.id("Form_submitForm_LastName"));
        fname.sendKeys("Testing");
        lname.sendKeys("Selenium");*/
        
        //3rd Approach
        //By locators:
		/*By fname = By.id("Form_submitForm_FirstName");
		By lname = By.id("Form_submitForm_LastName");
		
		driver.findElement(fname).sendKeys("testing");
		driver.findElement(lname).sendKeys("Selenium");*/
		
		//4th
		/*By fname = By.id("Form_submitForm_FirstName");
		By lname = By.id("Form_submitForm_LastName");
		
		getElement(fname).sendKeys("testing");
		getElement(lname).sendKeys("Selenium");*/
		
		//5th:
		By fname = By.id("Form_submitForm_FirstName");
		By lname = By.id("Form_submitForm_LastName");
		By jobTitle = By.id("Form_submitForm_JobTitle");
		By emailID = By.id("Form_submitForm_Email");
		By company = By.id("Form_submitForm_CompanyName");
		By contact = By.id("Form_submitForm_Contact");
		
		doSendKeys(fname,"testing");
		doSendKeys(lname,"Selenium");
		doSendKeys(jobTitle, "Lead");
		doSendKeys(emailID, "test@pmi.org");
		doSendKeys(company,"Infosys");
		doSendKeys(contact,"0987654321");
		
		//6th approach:Element Util Library
		
		//Different locators available in selenium
		//1.id -Ist priority
		//2:Linktext:Only for links--IV priority
		//3. by tagName 
		//4.xpath-III priority
		//5.cssSelector-III priority
		//6. name-II priority
		//7. className - V priority
		//PartialLinkText-V priority
				
		
	}
	
	public static WebElement getElement(By locator) {
		return driver.findElement(locator);
	}
	
	public static void doSendKeys(By locator, String value) {
		getElement(locator).sendKeys(value);
	}

}
