package seleniumsessions;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class DemoCarTest {

	public static void main(String[] args) {
		
		BrowserUtil br = new BrowserUtil();
		WebDriver driver = br.initDriver("chrome");
		br.launchUrl("https://demo.opencart.com/index.php?route=account/login");
		
		By emailId = By.id("input-email");
		By password = By.id("input-password");
		By registerLink = By.linkText("Register");
		By firstName = By.id("input-firstname");
		By lastName = By.id("input-lastname");
		By inputEmail = By.id("input-email");
		By telephone = By.id("input-telephone");
		By inputPassword = By.id("input-password");
		By confirmPassword = By.id("input-confirm");
		By name = By.name("agree");
		By continueButton = By.xpath("//input[@type='submit']");
		//input[@type='submit']
		
				
				
		ElementUtil eleUtil = new ElementUtil(driver);
		eleUtil.doSendKeys(emailId, "test20@pmi.org");
		eleUtil.doSendKeys(password, "test@123");
		eleUtil.doClick(registerLink);
		eleUtil.doSendKeys(firstName, "Kanishk");
		eleUtil.doSendKeys(lastName, "Tiwari");
		eleUtil.doSendKeys(inputEmail,"test20@pmi.org");
		eleUtil.doSendKeys(telephone, "0987654321");
		eleUtil.doSendKeys(inputPassword,"Password1");
		eleUtil.doSendKeys(confirmPassword,"Password1");
		eleUtil.doClick(name);
		eleUtil.doClick(continueButton);
		//driver.findElement (By.tagName("input")).click();
		
		//br.closeBrowser();
		

	}

}
