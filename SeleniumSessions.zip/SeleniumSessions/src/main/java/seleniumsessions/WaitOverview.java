package seleniumsessions;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

public class WaitOverview {

	public static void main(String[] args) {
		
		//wait -- sync --btwn selenium script and application
		
		//1. static wait : Thread.sleep(5000)--it will wait for the given time duration
		//2. dynamic wait: Wait dynamically 
		//10 secs, element is found in 2 sec then element wil not wait for 10 secs
		
		//if element is not found after 10 secs then throw exception
		
		//Dynamic Wait:
		  //a. Implicitly Wait
		  //b. Explicitly Wait:
		         //b.1: WebDriverWait:(class)
		         //b.2:FluentWait(class)
		         //WebDriverWait(c) extends FluentWait(c) implements Wait(I)
		         //Wait(I) --> until();
		         //Fluent Wait -->is having its own method alongwith until method
		WebDriver driver = new ChromeDriver();
		WebDriverWait wait = new WebDriverWait(driver, 3);
        
	}

}
