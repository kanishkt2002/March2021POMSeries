package seleniumsessions;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class CrossBrowserTesting {
	
	static WebDriver driver;

	public static void main(String[] args) {
		
		String browser = "firefox";
		
		if(browser.equals("chrome")) {
			System.setProperty("webdriver.chrome.driver","C:\\Users\\ktiwari\\Downloads\\chromedriver_win32\\chromedriver.exe");
			driver = new ChromeDriver();
			driver.get("https://www.amazon.com");
			String s = driver.getTitle();
			System.out.println(s);
			if(s.equals("Amazon.com: Online Shopping for Electronics, Apparel, Computers, Books, DVDs & more")) {
	        	System.out.println("Title is correct");
	        }else {
	        	System.out.println("Wrong title");
	        }
		driver.quit();
		}
		else if(browser.equals("firefox")) {
			System.setProperty("webdriver.gecko.driver","C:\\Users\\ktiwari\\Downloads\\geckodriver-v0.29.1-win64\\geckodriver.exe");
			driver = new FirefoxDriver();
			driver.get("https://www.facebook.com");
			String s1 = driver.getTitle();
			System.out.println(s1);
			if(s1.equals("Facebook - Log In or Sign Up")) {
	        	System.out.println("Title is correct");
	        }else {
	        	System.out.println("Wrong title");
	        }
		driver.quit();
		
		}
		else {
			System.out.println("Browser not found");
		}
		 
			
			
		
		/*switch (browser) {
		case "chrome":
			System.setProperty("webdriver.chrome.driver","C:\\Users\\ktiwari\\Downloads\\chromedriver_win32\\chromedriver.exe");
			driver = new ChromeDriver();
			driver.get("https://www.amazon.com");
			String s = driver.getTitle();
			System.out.println(s);
			 if(s.equals("Amazon.com: Online Shopping for Electronics, Apparel, Computers, Books, DVDs & more")) {
		        	System.out.println("Title is correct");
		        }else {
		        	System.out.println("Wrong title");
		        }
			driver.quit();
			break;
		case "firefox":
			System.setProperty("webdriver.gecko.driver","C:\\Users\\ktiwari\\Downloads\\geckodriver-v0.29.1-win64\\geckodriver.exe");
			driver = new FirefoxDriver();
			driver.get("https://www.facebook.com");
			String s1 = driver.getTitle();
			System.out.println(s1);
			 if(s1.equals("Facebook - Log In or Sign Up")) {
		        	System.out.println("Title is correct");
		        }else {
		        	System.out.println("Wrong title");
		        }
			driver.quit();
			
			break;

		default:
			System.out.println("Browser not found");
			//driver.quit();
			break;*/
			
			
		

	}

}
