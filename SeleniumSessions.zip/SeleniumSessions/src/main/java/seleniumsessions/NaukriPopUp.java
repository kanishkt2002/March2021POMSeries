package seleniumsessions;

import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class NaukriPopUp {
	static WebDriver driver;

	public static void main(String[] args) {
		
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		driver.get("https://naukri.com/");
         //driver.findElement(By.xpath("//img[@alt='OrangeHRM on youtube']")).click();
        
        //collect the window IDs:
        //driver.getWindowHandles()  --for the current window,get the window id
        Set<String> handles = driver.getWindowHandles();
        
        Iterator<String> it = handles.iterator();
        
        
        while(it.hasNext()) //to capture all the window
        	{        	
        	String id = it.next();
        	driver.switchTo().window(id);
        	System.out.println(driver.getTitle());
        	driver.close();
        }
        

	}

}
