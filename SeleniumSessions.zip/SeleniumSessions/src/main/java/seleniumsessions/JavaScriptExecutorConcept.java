package seleniumsessions;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class JavaScriptExecutorConcept {
	static WebDriver driver;

	  public static void main(String[] args) throws InterruptedException {
		
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		driver.get("https://demo.opencart.com/index.php?route=account/login");
		WebElement emailID= driver.findElement(By.id("input-email"));
		JavaScriptUtil jsUtil = new JavaScriptUtil(driver);
        System.out.println(jsUtil.getTitleByJS());
        
        //jsUtil.refreshBrowserByJS();
        
       // jsUtil.generateAlert("I am on login page"); // to generate random alert
        
      /* if(jsUtil.getPageInnerText().contains("Privacy Policy")) {
    	   System.out.println("PASS");//to get the text of webpage
       }*/
       
       //jsUtil.drawBorder(emailID);
        WebElement Login = driver.findElement(By.id("input-email"));
       jsUtil.flash(Login);//for flashing the field
       
      // jsUtil.clickElementByJS(Login); //when 2 buttons are overlapped and element is not interactable then we can use the java script executor.
       
       jsUtil.scrollPageDown();
       jsUtil.scrollPageUp();
       jsUtil.scrollPageDown("700");
       
       jsUtil.scrollIntoView(Login);
        
		
	}

}
