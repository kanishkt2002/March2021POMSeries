package seleniumsessions;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class SuggestionListHandle {

	static WebDriver driver;
	public static void main(String[] args) throws InterruptedException {
		
			
			WebDriverManager.chromedriver().setup();
			driver = new ChromeDriver();
			
			driver.get("https://www.amazon.in/");
			Thread.sleep(2000);
			driver.findElement(By.xpath("//input[@id='twotabsearchtextbox']")).sendKeys("Dresses");
			Thread.sleep(4000);
			
			By suggdropdown = By.xpath("//div[@id='nav-flyout-iss-anchor']//div[@id='suggestions']//span");
			suggdropdown(suggdropdown,"for women stylish kurti");
			
				}
	       public static void suggdropdown(By Locator,String Value) {
	    	   
	    	   List<WebElement> suggdropdown= 
						driver.findElements(Locator);
				
				//System.out.println(suggdropdown);
				
				for(WebElement e : suggdropdown) {
					System.out.println(e.getText());
					if(e.getText().equals(Value)) {
						e.click();
						break;
					}
					
				}
	    	   
	    	   
		
	        }


}
