package seleniumsessions;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class WebElementExceptions {
	static WebDriver driver;

	public static void main(String[] args) {
		
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		
		driver.get("https://demo.opencart.com/index.php?route=account/login");
		
		//driver.findElement(By.id("input")).sendKeys("123");//No Such Element Exception
		
		//No Such Element Exception -- element is not available on the page
		//ElementNotFoundException--It is not valid exception for Selenium
		
		driver.findElement(By.xpath("input")).click();//InvalidSelectorException
		//InvalidSelectorException - when invalid selector is provided
		
		List<WebElement> loginList = driver.findElements(By.id("input-email23"));//In a list when invalid locator is provided it will not throw exception it will give 0 /blank list
		System.out.println(loginList.size());
		
		if(loginList.size()<1) {
			System.out.println("login button is not found");
		}
		
		//StaleElementException
		//IllegalStetException--> When driver path is not correct or executable files are not setup
		//NoSuchSessionException-->When we use driver after quit/close
		
		
		
	}

}
