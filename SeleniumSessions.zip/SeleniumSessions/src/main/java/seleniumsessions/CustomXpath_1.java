package seleniumsessions;

public class CustomXpath_1 {

	public static void main(String[] args) {
		
		//Xpath:
		//1.Absolute Xpath://html/body/div[3]/ul/li/a
		//2:Relative Xpath or custome xpath:
		//input
		//input[@attr]
		//input[@attr='value']
		//1.//htmltag[@attr='value']
		
		//2. //htmltag[@attr1='value' and @attr2='value']
		//htmltag[@attr1='value' or @attr2='value']
		
		//input[@name='email' and @type='text']
		//input[@name='email' or @type='text']
		
		//input[@type='text'] ---3 elemnts
		//*[@type='text']  --3 elements from all the elements
		
		//text() function
		//h2[text()='Refreshing business software that your teams will love']
		
		//Contains() function:
		//htmltag[contains(@attr,'value')]
		//input[contains(@name,'username')]
		
		//htmltag[contains(@attr1,'value') and contains(@attr2,'value')]
		
		//contains() with text():
		//htmltag[contains(text(),'value')]
		//h2[contains[text(),'Refreshing')]
		
		//contains() with text() and attribute:
		//htmltag[contains(text() ='value') and contains(@attr='value')]
		//a[contains(text(),'Customer Service') and contains(@class,'nav-a  ')]
		
		//contains with links, span,p,small
		//small[contains(text(),'value')]
		
		//position() function
		// input[@type='text'])[position()=1]
		// (//input[@class='form-control'])[position()=1]
	    // (//input[@class='form-control'])[1]
		
		
		//last():
		//(//input[@class = 'form-control'])[last()]
		
		//dynamic ids or any attribute:
		
		//<input id ="username_123">
		//<input id ="username_345">
		//<input id ="username_567">
		//Ext JS		
		//input[contains(@id,'username_')] --To handle dynamic attr
		
		//starts-With():
		// (//div[starts-with(@class,'navFooterLinkCol')])
		//input[starts-with	(@id,'username_')]
		
		

	}

}
