package seleniumsessions;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class ImplicitlyWaitConcept {

	public static void main(String[] args) {
		
		//Imp Wait:
		//1.It's only applicable for web elements
		//2.It's not applicable for non web elements: title,url,alerts
		//3. global wait -- it will be applied on all the web elements throughout the session
		//Dynamic Wait --> Total time =10 secs, found == 2 secs
		//remaining secs: 8 secs(ignored)
		
		WebDriverManager.chromedriver().setup();
		WebDriver driver =new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		driver.get("https://demo.opencart.com/index.php?route=account/login");
		
		//for all Webelement with FindElement -- implicitly wait of 10 secs will be applied
		
        driver.findElement(By.id("input-email")).sendKeys("test@gmail.com");
        driver.findElement(By.id("input-password")).sendKeys("password");
        driver.findElement(By.xpath("//input[@value='Login']")).click();
        
        
	}

}
