package seleniumsessions;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

import io.github.bonigarcia.wdm.WebDriverManager;

public class ActionsSendKeysClick {

	 static WebDriver driver;
		public static void main(String[] args) throws InterruptedException {
			
				
				WebDriverManager.chromedriver().setup();
				driver = new ChromeDriver();
				driver.manage().window().maximize();
				
				driver.get("https://demo.opencart.com/index.php?route=account/login");
				
				By email = By.id("input-email");
				By password = By.id("input-password");
				By login = By.xpath("//input[@value='Login']");
				
				doActionsSendKeys(email,"kanishk@gmail.com");
				doActionsSendKeys(password,"kanishk");
				doActionsClick(login);
				
				/*Actions act = new Actions(driver);
				
				act.sendKeys(driver.findElement(email), "kanishk@gmail.com").perform();
				act.sendKeys(driver.findElement(password), "password123").perform();
				
				act.click(driver.findElement(login)).perform();*/
	}

		
		   public static WebElement getElement(By locator) {
			return driver.findElement(locator);
			   
		   }
		   
		   public static void doActionsSendKeys(By locator, String Value) {
			   Actions act = new Actions(driver);
			   act.sendKeys(getElement(locator), Value).perform();
		   }
		   
		   public static void doActionsClick(By locator) {
			   Actions act = new Actions(driver);
			   act.click(getElement(locator)).perform();
		   }

}
