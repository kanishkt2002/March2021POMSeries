package TestNGSessions;

import org.testng.annotations.Test;

public class DependsOnTest {
	
	@Test
	public void userCreateTest() {
		System.out.println("Create user");
		int i =9/0;
	}
	
	@Test(dependsOnMethods="userCreateTest")
	public void HomeTest() {
		System.out.println("Home page displayed");
	}

}
