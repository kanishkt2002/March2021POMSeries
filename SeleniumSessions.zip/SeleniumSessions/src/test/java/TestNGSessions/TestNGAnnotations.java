package TestNGSessions;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class TestNGAnnotations {
	
	//Pre conditions --> @Before suite,@before test,@beforeClass,@Before Method
	//Test Case -->@Test+Assertions
	//Post Steps --> @AM,@AC,@AT,@AS
	
	//  Pre condition: Open the browser
	                 //Launch the URL
	
	//TC_01: check the title with some steps -->Actual vs Expected
	//TC_02: Search test(With some steps) --> actual vs Expected
	
	//Post Steps: close the browser
	
	/**
	 * before suite -I
	    before test -II
	    before class - III
	    
	before Method - IV
	search test -  t1
	After Method - V
	
	    before Method - VI
	    title test - t2
	    After Method - VII
	    
	After Class - VIII
	After Test - IX
	After Suite - X
	*/
	
	@BeforeSuite
	public void beforeSuite() {
		System.out.println("before suite");
	}
	
	@BeforeTest
	public void beforeTest() {
		System.out.println("before test");
	}
	
	@BeforeClass
	public void beforeClass() {
		System.out.println("before class");
	}
	
	@BeforeMethod
	public void beforeMethod(){
		System.out.println("before Method");
	}
	
	@Test
	public void titleTest() {
		System.out.println("title test");
		Assert.assertEquals("google", "google");
	}
	
	@Test
	public void searchTest() {
		System.out.println("search test");
		Assert.assertEquals("naveen", "naveen");
	}
	
	@AfterMethod
	public void afterMethod() {
		System.out.println("After Method");
	}
	
	@AfterClass
	public void afterClass() {
		System.out.println("After Class");
	}
	
	
	@AfterSuite
	public void afterSuite() {
		System.out.println("After Suite");
	}
	
	@AfterTest
	public void afterTest() {
		System.out.println("After Test");
	}

}
